//
//  GTConfig.h
//  GoPlaySDK
//
//
//

#ifndef __GoPlaySDK_GTConfig__
#define __GoPlaySDK_GTConfig__


#define GAME_ID "9268dcab-aeef-4cae-828f-3ae951513ffa"



#endif /* defined(__GoPlaySDK__GTConfig__) */
